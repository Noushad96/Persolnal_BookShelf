import React, { useEffect, useState } from "react";

// const mera = JSON.parse(localStorage.getItem("bookData"));

const Mybook = (bookData) => {
  const [mybookdata, setMybookdata] = useState(bookData.bookData);

  console.log("bookData from my book==> ", bookData);
  console.log("bookData from my book==> ", Object.keys(bookData));

  

  console.log("mybookdata==> ", mybookdata);

  return (
    <>
      <div>
        <div className="font-semibold mb-8 text-left px-[5%]">My BookShelf</div>
        <div className="Book_body  px-[5%]">
          <div className="flex flex-row flex-wrap gap-4 justify-center  sm:justify-start">
            {mybookdata?.map((myfav, index) => (
              <div
                key={index}
                className="book_cart border-black/50 border-2 rounded  p-4 "
              >
                <div className="Book_title">
                  <span>Book title :</span>
                  <span>{myfav.title}</span>
                </div>
                <div className="Edition">
                  {" "}
                  <span>Edition Count :</span>
                  {myfav.edition_count}
                </div>
                <div className="myShelf_Btn">
                  <button>Add to bookShelf </button>
                </div>
              </div>
            ))}

            {/* <div className="book_cart border-black/50 border-2 rounded  p-4 ">
              <div className="Book_title">
                Book title : <span>Lord of the Ring</span>
              </div>
              <div className="Edition"> Edition Count : 195</div>
              <div className="myShelf_Btn">
                <button>Add to bookShelf </button>
              </div>
            </div>
            <div className="book_cart border-black/50 border-2 rounded  p-4 ">
              <div className="Book_title">
                Book title : <span>Lord of the Ring</span>
              </div>
              <div className="Edition"> Edition Count : 195</div>
              <div className="myShelf_Btn">
                <button>Add to bookShelf </button>
              </div>
            </div>
            <div className="book_cart border-black/50 border-2 rounded  p-4 ">
              <div className="Book_title">
                Book title : <span>Lord of the Ring</span>
              </div>
              <div className="Edition"> Edition Count : 195</div>
              <div className="myShelf_Btn">
                <button>Add to bookShelf </button>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </>
  );
};

export default Mybook;
